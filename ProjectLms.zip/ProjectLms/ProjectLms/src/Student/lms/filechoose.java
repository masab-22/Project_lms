package Student.lms;
import java.awt.*;
import  java.awt.event.*;
import java.io.File;
import javax.swing.*;
public class filechoose extends JFrame implements ActionListener {


        JButton button;
    private JButton filechoosebutton;
    private JPanel file;

    filechoose(){
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JFrame frame = new JFrame( "User_Portal" );
            frame.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            frame.pack();
        JLabel label = new JLabel();
        label.setText("STUDENT LMS");
            button = new JButton("choose file");
            button.addActionListener(this);
        frame.setSize( 1800, 1400 );
        ImageIcon image = new ImageIcon( "man.png" );
        frame.setIconImage( image.getImage() );

            this.add(button);
            this.pack();
            this.setVisible(true);
        filechoosebutton.addActionListener( new ActionListener() {
            @Override   public void actionPerformed(ActionEvent e) {
                new filechoose();
            }
        } );

    }

        @Override
        public void actionPerformed(ActionEvent e) {

            if(e.getSource()==button) {

                JFileChooser fileChooser = new JFileChooser();

                fileChooser.setCurrentDirectory(new File(".")); //sets current directory

                int response = fileChooser.showOpenDialog(null); //select file to open
                //int response = fileChooser.showSaveDialog(null); //select file to save

                if(response == JFileChooser.APPROVE_OPTION) {
                    File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
                    System.out.println(file);
                }
            }
        }
    }



