package Student.lms;

import javax.swing.*;

public class Teachersinfo {
    private JPanel teacherspanel;
}
