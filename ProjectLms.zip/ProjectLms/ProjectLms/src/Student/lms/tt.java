package Student.lms;

import javax.swing.*;

public class tt {
    private JButton button1;
}
