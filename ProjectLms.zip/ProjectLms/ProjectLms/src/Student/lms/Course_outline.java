package Student.lms;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Course_outline {
    private JPanel coursepanel;
    private JButton homeButton;
    private JList list1;

    public Course_outline() {
    JFrame frame = new JFrame( "User_Portal" );
    frame.add( coursepanel );
    frame.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
    frame.pack();
    frame.setVisible( true );
    frame.setSize( 1300, 1000 );
    ImageIcon image = new ImageIcon( "man.png" );
    frame.setIconImage( image.getImage() );


        homeButton.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Home_Page();
                frame.dispose();
            }
        } );
    }
}
