package Student.lms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home_Page {
    private JPanel homepanel;
    private JButton classtaskbutton;
    private JButton attendanceButton;
    private JButton courseButton;
    private JButton addStudentButton;

    Home_Page() {

        JFrame frame = new JFrame( "User_Portal" );
        frame.add( homepanel );
        frame.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
        frame.pack();
        frame.setVisible( true );
        frame.setSize( 1000, 1000 );
        ImageIcon image = new ImageIcon( "man.png" );
        frame.setIconImage( image.getImage() );

        frame.getContentPane().setBackground( new Color( 255, 0, 0 ) );


        courseButton.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Course_outline();
                frame.dispose();
            }
        } );
        addStudentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               new Add_Student();
               frame.dispose();
            }
        });
        attendanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Attandance();
                frame.dispose();
            }
        });
        classtaskbutton.addActionListener( new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            new filechoose();
            frame.dispose();
            }
        } );
    }
}