package Student.lms;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Add_Student {
    private JButton addStudentButton;
    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton addButton;
    private JLabel show;
    private JButton homeButton;
    public static int id[]=new int[20];
    public static String name[]=new String[20];
    static int g=0;
    static int f=0;
    static int a;


    public Add_Student() {
    JFrame frame = new JFrame( "Add Student" );
    frame.add(panel1);
    frame.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
    frame.pack();
    frame.setVisible( true );
    frame.setSize( 1000, 1000 );
    ImageIcon image = new ImageIcon( "man.png" );
    frame.setIconImage( image.getImage() );




        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                 a=Integer.parseInt(textField1.getText());


                boolean c=!false;
                while(c) {
                    int id1=Integer.parseInt(textField2.getText());
                    for (int i = g; i < a; i++) {
                        id[i] = id1;
                        name[i] = textField3.getText();
                        break;
                    }
                    g++;
                    f++;
                    show.setText(String.valueOf(f));
                    textField2.setText("");
                    textField3.setText("");
                    if(g==a){
                        c=false;
                    }

                }
                textField1.setText("");
            }
        });
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Home_Page();
                frame.dispose();
            }
        });
    }
}
