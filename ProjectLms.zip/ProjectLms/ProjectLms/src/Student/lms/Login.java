package Student.lms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Login {
    private JTextField user_input;
    private JPasswordField user_password;
    private JButton loginButton;
    private JPanel Login; String pass = "bombastic";

    private JLabel show;
    String input= "Masab";

    public Login() {
    loginButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            if(user_input.getText().isEmpty() && user_password.getText().isEmpty()){
                show.setText("Field's are empty");
            }
            else if(user_input.getText().isEmpty()){
                show.setText("User name field are empty");
            }
            else if(user_password.getText().isEmpty()){
                show.setText("Password field are empty");
            }
            else if (user_input.getText().equalsIgnoreCase(input) && user_password.getText().equalsIgnoreCase(pass)) {
//                  Home_page h=new Home_page();
                new Home_Page();

            }
            else if(!user_input.getText().equalsIgnoreCase(input) || !user_password.getText().equalsIgnoreCase(pass)){
                show.setText("Incorrect");
            }
        }
    });
        user_input.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyChar();
                if(key==10){
                    user_password.requestFocus();
                }
            }
        });
        user_password.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyChar();
                if(key==10){
                    loginButton.requestFocus();
                }
            }
        });
        loginButton.addKeyListener(new KeyAdapter() {



            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyChar();
                if(key==10){
                    new Home_Page();
                }
            }
        });
    }

    public static void main(String[] args) {
        JLabel label = new JLabel();
        label.setText("STUDENT LMS");

        JFrame frame = new JFrame("User_Portal");
        frame.setContentPane(new Login().Login);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setSize(1000,1000);



        ImageIcon image=new ImageIcon("man.png");
        frame.setIconImage(image.getImage());


    }
}
