package Student.lms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Attandance {
    private JLabel name1;
    private JLabel showid;
    private JButton presentButton;
    private JButton absentButton;
    private JPanel panel3;
    private JButton nextButton;
    private JLabel showpre;
    private JLabel showabs;
    private JButton homeButton;
//
//    String pre1=p;
//    String absent1=b;

    public static String pre[]=new String[20];
    public static String adsent1[]=new String[20];

    static int p=0;
//    static String a="B";

    Attandance(){
        JFrame frame = new JFrame( "Attandence" );
        frame.add(panel3);
        frame.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
        frame.pack();
        frame.setVisible( true );
        frame.setSize( 1000, 1000 );
        ImageIcon image = new ImageIcon( "man.png" );
        frame.setIconImage( image.getImage() );

        frame.getContentPane().setBackground( new Color( 145, 255, 225 ) );


       for(int i=0;i<Add_Student.a;i++){
           name1.setText(Add_Student.name[i]);
           showid.setText(String.valueOf(Add_Student.id[i]));
           break;
        }


        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                showpre.setText("");
                showabs.setText("");
                int a=1;
                for (int i = a; i < Add_Student.a; i++) {

                    name1.setText(Add_Student.name[i]);
                    showid.setText(String.valueOf(Add_Student.id[i]));
                    break;
                }
                a++;

            }
        });
        presentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                boolean a=!false;
//                while(a) {
                    for (int i = p; i < 20; i++) {
                        pre[i] = "p";
                        break;
                    }
                    p++;
//                    if(p==Add_Student.a){
//                        a=false;
//                    }
//                }
                showpre.setText("Present");
            }
        });
        absentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                boolean N=!false;
//                while(N) {

                    for (int i = p; i < 20; i++) {
                        adsent1[i] = "A";
                        break;
                    }
                    p++;
//                    if(p==Add_Student.a){
//                        N=false;
//                    }
//                }
                showabs.setText("Absent");
            }
        });
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Home_Page();
                frame.dispose();
            }
        });
    }
}
